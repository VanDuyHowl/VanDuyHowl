package Register;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class HomeController {

	@FXML
	private Label welcome;

	@FXML
	private TableView<User> usertable = new TableView<User>();
	@FXML
	private TextField emailH;
	@FXML
	private TextField fullnameH;
	@FXML
	private Button btnAdd;
	@FXML
	private Button btnUpdate;
	@FXML
	private Button btnDelete;
	@FXML
	private ImageView imgView;

	@FXML
	private TableColumn<User, String> emailColumn;

	@FXML
	private TableColumn<User, String> fullnameColumn;

	private User loginedUser;
	private String userName;

	@FXML
	public void onClickExit() {
		// từ thành phần con dò ra (cửa cổ)
		welcome.getScene().getWindow().hide();
	}

	public void initialize() {
		// Nội dung khi mở màn hình Home
		Platform.runLater(() -> {
			//welcome.setText("Xin chào " + loginedUser.getFullName());
		});

		// Khởi tạo cột trong bảng
		fullnameColumn.setCellValueFactory(new PropertyValueFactory<User, String>("email"));

		emailColumn.setCellValueFactory(new PropertyValueFactory<User, String>("fullName"));

		// Lấy ds User từ CSDL
		List<User> listUser = UserDAO.listAllUser();
		ObservableList<User> obsList = FXCollections.observableArrayList(listUser);
		// Đưa vào bảng tableview
		usertable.setItems(obsList);
	}

	@FXML
	public void onClickRow() {
		User selectedUser = usertable.getSelectionModel().getSelectedItem();
		emailH.setText(selectedUser.getEmail());
		fullnameH.setText(selectedUser.getFullName());
		// Dua anh vao ImageView
		FileInputStream input;
		try {
			if (selectedUser.getImgPath() != null) {
				input = new FileInputStream(selectedUser.getImgPath());
				Image image = new Image(input);
				imgView.setImage(image);
			} else {
				imgView.setImage(null);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// Xử lý sự kiện bấm nút Add sau khi nhập dữ liệu vào 3 ô
	@SuppressWarnings("unchecked")
	public void onClickAdd() {
		// Tạo đối tượng sinh viên từ 3 ô dữ liệu nhập vào
		User std = new User(emailH.getText(), fullnameH.getText());

		// Thêm vào danh sách dữ liệu của tableview
		usertable.getItems().add(std);
	}

	// Xử lý sự kiện bấm nút sua một dòng được chọn trong bảng
	public void onClickEdit() {
		// Lấy về chỉ số dòng đang được chọn trên bảng
		int selectedIndex = usertable.getSelectionModel().getSelectedIndex();
		// Lấy về đối tượng dữ liệu tương ứng với dòng được chọn
		 User selectedUser = usertable.getItems().get(selectedIndex);

		// Thay đổi dữ liệu trong đối tượng sinh viên được chọn
		 selectedUser.setEmail(emailH.getText());
		 selectedUser.setFullName(fullnameH.getText());
		 // Cập nhật lại đối tượng dữ liệu tại vị trí được chọn để hiển thị lên bảng

		usertable.getItems().set(selectedIndex, selectedUser);
	}

	// Xử lý sự kiện bấm nút xóa một dòng được chọn trong bảng
	public void onClickDelete() {

	}

	// Phương thức gán dữ liệu cho userName
	public void setLoginedUser(User loginedUser) {
		this.loginedUser = loginedUser;
	}

}