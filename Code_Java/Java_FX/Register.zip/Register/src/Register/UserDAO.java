package Register;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class UserDAO {
	public static List<User> listAllUser(){
		List<User> listUser = new ArrayList<>();
		
		String jdbcURL = "jdbc:ucanaccess://lib/QLNS.accdb";
		String jdbcUser = "";
		String jdbcPass = "";
		
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
			String sql = "Select * from tbluser";
			Statement ps = con.createStatement();
			
			ResultSet rs = ps.executeQuery(sql);
			
			while(rs.next()) {
				User user = new User();
				user.setEmail(rs.getString("email"));
				user.setFullName(rs.getString("fullname"));
				user.setImgPath(rs.getString("imgPath"));
				
				// Them vao danh sach
				listUser.add(user);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ko thấy driver");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		return listUser;
	}
	
	public static User checkcUser(String email) {
		String jdbcURL="jdbc:ucanaccess://lib/QLNS.accdb";
		String dbUser="";
		String dbPassword="";
		
		User user=null;
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		
			Connection connection=DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
			String sql="SELECT *fROM tbluser WHERE email=?";
			PreparedStatement statement=connection.prepareCall(sql);
			statement.setString(1, sql);
			
			ResultSet result=statement.executeQuery();
			
			user=null;
			
			if(result.next())
			{
				user=new User();
				user.setFullName(result.getString("HoTen"));
				user.setEmail(email);
			}
			
			connection.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
}
