package Login;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.channels.SelectableChannel;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class HomeController {

	@FXML
	private Label welcome;
	@FXML
	private Label msg;

	@FXML
	private TableView<Product> dataTable = new TableView<Product>();
	@FXML
	private TextField emailH;
	@FXML
	private TextField fullnameH;

	@FXML
	private TextField maspH;
	@FXML
	private TextField tenspH;
	@FXML
	private TextField slgH;
	@FXML
	private TextField giaH;
	@FXML
	private TextField thuonghieuH;

	@FXML
	private ImageView imgView;

	@FXML
	private Button btnAdd;
	@FXML
	private Button btnUpdate;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnImg;

	@FXML
	private TableColumn<Product, String> codeColumn;
	@FXML
	private TableColumn<Product, String> fullnameColumn;
	@FXML
	private TableColumn<Product, String> quantityColumn;
	@FXML
	private TableColumn<Product, String> priceColumn;
	@FXML
	private TableColumn<Product, String> brandColumn;

	private User loginedUser;
	private int role;
	private String img;
	private Desktop desktop = Desktop.getDesktop();

	@FXML
	public void onClickExit() {
		// Từ thành phần con dò ra (cửa cổ)
		welcome.getScene().getWindow().hide();
	}

	@FXML
	public void initialize() {
		// Nội dung khi mở màn hình Home
		Platform.runLater(() -> {
			welcome.setText("Xin chào " + loginedUser.getFullname());

			// Nếu là khach -> disable cac nut bam
			if (loginedUser.getRole() == 1) {
				btnAdd.setDisable(true);
				btnUpdate.setDisable(true);
				btnDelete.setDisable(true);
				btnImg.setDisable(true);
			}
		});

		// Khởi tạo cột trong bảng
		codeColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("maSP"));
		fullnameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("tenSP"));

		// Lấy ds User từ CSDL
		List<Product> listProduct = ProductDAO.listAllUser();
		ObservableList<Product> obsList = FXCollections.observableArrayList(listProduct);
		// Đưa vào bảng tableview
		dataTable.setItems(obsList);

	}

	@FXML
	public void onClickRow() {
		msg.setText(null);

		// Lấy dữ liệu từ các dòng được chọn gán vào các ô bên phải tương ứng
		Product selectedProduct = dataTable.getSelectionModel().getSelectedItem();
		maspH.setText(selectedProduct.getMaSP());
		tenspH.setText(selectedProduct.getTenSP());
		slgH.setText(selectedProduct.getSlgSP());
		giaH.setText(selectedProduct.getGiaSP());
		thuonghieuH.setText(selectedProduct.getThuonghieuSP());

		// Đưa ảnh vào ImageView
		FileInputStream input;
		try {
			if (selectedProduct.getImgPath() != null) {
				img = selectedProduct.getImgPath();
				input = new FileInputStream(selectedProduct.getImgPath());
				Image image = new Image(input);
				imgView.setImage(image);
				try {
					// Đóng đối tượng ảnh nếu đang được sử dụng
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				imgView.setImage(null);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	private void onClickImg() {
		// Lấy Stage hiện tại từ button
		Stage stage = (Stage) btnImg.getScene().getWindow();

		final FileChooser fileChooser = new FileChooser();

		// Tạo tuỳ chọn tệp
		fileChooser.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.img"),
				new FileChooser.ExtensionFilter("All Files", "*.*"));

		// Mở hộp thoại chọn tệp
		File file = fileChooser.showOpenDialog(stage);
		if (file != null) {
			// Lấy đường dẫn tệp và hiển thị trong ImgView
			Image image = new Image(file.toURI().toString());
			imgView.setImage(image);
			img = file.getAbsolutePath();
		}
	}

	// Xử lý sự kiện bấm nút Add sau khi nhập dữ liệu vào 5 ô
	@FXML
	public void onClickAdd() {

		if (maspH.getText().isEmpty()) {
			msg.setText("Mã sản phẩm không được để trống!");
			return;
		}
		if (ProductDAO.checkSP(maspH.getText()) == true) {
			msg.setText("Đã có mã sản phẩm này rồi !");
		} else {
			if (img != null) {
				// Đường dẫn tệp nguồn
				Path sourcePath = Paths.get(img);

				// Đường dẫn tệp đích
				Path targetDir = Paths.get("img");
				String cptenSP = tenspH.getText();
				Path targetPath = targetDir.resolve(cptenSP + ".jpg");

				try {
					Files.copy(sourcePath, targetPath, StandardCopyOption.COPY_ATTRIBUTES);
					img = targetPath.toString();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			// Tạo đối tượng sinh viên từ 5 ô dữ liệu nhập vào
			Product std = new Product(img, maspH.getText(), tenspH.getText(), slgH.getText(), giaH.getText(),
					thuonghieuH.getText());

			// Thêm vào danh sách dữ liệu của tableview và CSDL
			dataTable.getItems().add(std);
			ProductDAO.addSP(std);
			msg.setText("Đã thêm vào trong CSDL!");
			System.out.println("Đã thêm vào trong CSDL!");
		}
	}

	// Xử lý sự kiện bấm nút SỬA một dòng được chọn trong bảng
	@FXML
	public void onClickEdit() {
		// Lấy về chỉ số dòng đang được chọn trên bảng
		int selectedIndex = dataTable.getSelectionModel().getSelectedIndex();

		if (ProductDAO.checkSP(maspH.getText()) == true) {
			if (selectedIndex >= 0) {
				if (img != null) {
					// Đường dẫn tệp nguồn
					Path sourcePath = Paths.get(img);

					// Đường dẫn tệp đích
					Path targetDir = Paths.get("img");
					String cptenSP = tenspH.getText();
					Path targetPath = targetDir.resolve(cptenSP + ".jpg");

					try {
						if (Files.exists(targetPath)) {
							// Hiển thị thông báo cho người dùng rằng tệp sẽ bị ghi đè
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("Xác nhận");
							alert.setHeaderText("Tệp sẽ bị ghi đè");
							alert.showAndWait();
						}
						Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
						img = targetPath.toString();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				// Lấy về đối tượng dữ liệu tương ứng với dòng được chọn
				Product selectedProduct = dataTable.getItems().get(selectedIndex);

				// Thay đổi dữ liệu trong đối tượng sản phẩm được chọn
				selectedProduct.setMaSP(maspH.getText());
				selectedProduct.setTenSP(tenspH.getText());
				selectedProduct.setSlgSP(slgH.getText());
				selectedProduct.setGiaSP(giaH.getText());
				selectedProduct.setThuonghieuSP(thuonghieuH.getText());
				selectedProduct.setImgPath(img);

				// Cập nhật lại đối tượng dữ liệu tại vị trí được chọn để hiển thị lên bảng và
				// trong CSDL
				dataTable.getItems().set(selectedIndex, selectedProduct);
				ProductDAO.updateSP(selectedProduct);
				System.out.println("Đã sửa thành công vào CSDL!");
				msg.setText("Đã sửa thành công vào CSDL!");
			}
		} else {
			msg.setText("Sản phẩm không có trong CSDL!");
			System.out.println("Sản phẩm không có trong CSDL!");
		}
	}

	// Xử lý sự kiện bấm nút XÓA một dòng được chọn trong bảng
	@FXML
	public void onClickDelete() {
		// Lấy về chỉ số dòng đang được chọn trên bảng
		int selectedIndex = dataTable.getSelectionModel().getSelectedIndex();

		// Hiện hộp thoại alert Confirm
		if (selectedIndex >= 0) {
			// Lấy về đối tượng dữ liệu tương ứng với dòng được chọn
			Product selectedProduct = dataTable.getItems().get(selectedIndex);

			// Hiển thị hộp thoại xác nhận
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Xác nhận xóa");
			alert.setHeaderText("Bạn chắc chắn muốn xóa sản phẩm này?");
			alert.setContentText("Tên sản phẩm: " + selectedProduct.getTenSP());

			// Lấy kết quả từ hộp thoại alert confirm
			Optional<ButtonType> result = alert.showAndWait();
			if (result.isPresent() && result.get() == ButtonType.OK) {
				if (img != null) {
					// Đường dẫn tệp đích
					Path targetDir = Paths.get("img");
					String cptenSP = tenspH.getText();
					Path targetPath = targetDir.resolve(cptenSP + ".jpg");
					// Xóa ảnh có trong file img
					if (Files.exists(targetPath)) {
						try {
							Files.delete(targetPath);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							System.out.println("Không xóa được ảnh!");
							e.printStackTrace();
						}
					}
				}
				// Xóa đối tượng tại vị trí được chọn và trong CSDL
				dataTable.getItems().remove(selectedIndex);
				ProductDAO.deleteSP(selectedProduct);

				msg.setText("Đã xóa thành công!");
				System.out.println("Đã xóa thành công!");
			} else {
				msg.setText("Đã hủy xóa!");
				System.out.println("Đã hủy xóa!");
			}
		} else {
			// Hiện hộp thoại alert warning
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("Cảnh báo");
			alert.setHeaderText("Không thể xóa sản phẩm");
			alert.setContentText("Vui lòng chọn một dòng để xóa");
			alert.showAndWait();
		}
	}

	public void setRole(int role) {
		this.role = role;
	}

	public User getLoginedUser() {
		return loginedUser;
	}

	public void setLoginedUser(User loginedUser) {
		this.loginedUser = loginedUser;
	}

	private void openFile(File file) {
		try {
			this.desktop.open(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}