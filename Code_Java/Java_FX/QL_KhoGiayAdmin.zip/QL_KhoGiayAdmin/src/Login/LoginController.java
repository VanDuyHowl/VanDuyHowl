package Login;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class LoginController {

	@FXML
	private TextField EmailTF;
	@FXML
	private  PasswordField PasswordTF;

	@FXML
	private Label msg;

	@FXML
	public void onClick() {
		User user = UserDAO.checkUser(EmailTF.getText());
		if (user == null) {
			msg.setText("Email không được để trống hoặc không có trong CSDL!");
			return;
		} else if (PasswordTF.getText().equals(user.getPassword())) {
			
			//Đóng cửa sổ đăng ký
			EmailTF.getScene().getWindow().hide();

			//Mở ra cửa sổ Home và truyền thông tin User đăng ký cho cửa sổ Home
			goHomeScreen(new User(user.getEmail(), user.getFullname(), user.getRole()));
		}else {
			msg.setText("Sai mật khẩu, vui lòng nhập lại!");
		}

	}

	public void goHomeScreen(User loginedUser) {
		try {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("HomeGUI.fxml"));

			// Đọc file fxml và vẽ giao diện.
			Parent root = fxmlLoader.load();

			// Lấy ra HomeController để truyền dữ liệu vào
			HomeController hc = fxmlLoader.getController();
			hc.setLoginedUser(loginedUser);

			// Thêm layout vào Scene
			Scene scene = new Scene(root);

			// Thêm Scene vào Stage
			Stage homeStage = new Stage();
			homeStage.setScene(scene);

			// Hiển thị Stage
			homeStage.setTitle("Home");
			homeStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
