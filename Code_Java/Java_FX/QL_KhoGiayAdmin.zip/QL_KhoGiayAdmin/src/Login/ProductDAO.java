package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {
	public static List<Product> listAllUser() {
		List<Product> listProduct = new ArrayList<>();

		String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		String jdbcUser = "";
		String jdbcPass = "";

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
			String sql = "Select * from tblproduct";
			Statement ps = con.createStatement();

			ResultSet rs = ps.executeQuery(sql);

			while (rs.next()) {
				Product product = new Product();
				product.setImgPath(rs.getString("imgPath"));
				product.setMaSP(rs.getString("maSP"));
				product.setTenSP(rs.getString("tenSP"));
				product.setSlgSP(rs.getString("slgSP"));
				product.setGiaSP(rs.getString("giaSP"));
				product.setThuonghieuSP(rs.getString("thuonghieuSP"));

				// Them vao danh sach
				listProduct.add(product);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ko thấy driver");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return listProduct;
	}

	public static Boolean checkSP(String maSP) {

		String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		String jdbcUser = "";
		String jdbcPass = "";

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
			String sql = "Select * from tblproduct Where maSP = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, maSP);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return true;
			}
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ko thấy driver");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return false;
	}

	public static boolean addSP(Product sp) {
		String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		String dbUser = "";
		String dbPassword = "";

		boolean rowInserted = false;
		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

			Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

			String sql = "INSERT INTO tblproduct (imgPath,tenSP,slgSP,giaSP,thuonghieuSP,maSP) VALUES (?, ?, ?, ?, ?, ?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, sp.getImgPath());
			statement.setString(2, sp.getTenSP());
			statement.setString(3, sp.getSlgSP());
			statement.setString(4, sp.getGiaSP());
			statement.setString(5, sp.getThuonghieuSP());
			statement.setString(6, sp.getMaSP());

			rowInserted = statement.executeUpdate() > 0;

			statement.close();
			connection.close();

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return rowInserted;
	}
	public static boolean updateSP(Product sp) {
	    String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
	    String dbUser = "";
	    String dbPassword = "";

	    boolean rowUpdated = false;
	    try {
	        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");

	        Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
            PreparedStatement statement = connection.prepareStatement("UPDATE tblproduct SET imgPath = ?, tenSP = ?, slgSP = ? , giaSP = ?,thuonghieuSP = ? WHERE maSP = ?");

            statement.setString(1, sp.getImgPath());
			statement.setString(2, sp.getTenSP());
			statement.setString(3, sp.getSlgSP());
			statement.setString(4, sp.getGiaSP());
			statement.setString(5, sp.getThuonghieuSP());
			statement.setString(6, sp.getMaSP());

            rowUpdated = statement.executeUpdate() > 0;
	        

	    } catch (ClassNotFoundException | SQLException e) {
	        e.printStackTrace();
	    }
	    return rowUpdated;
	}
	
	 public static boolean deleteSP(Product sp) {
		 	String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		    String dbUser = "";
		    String dbPassword = "";
		    
		    boolean rowDeleted = false;
	         
		    try {
		        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		        Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		        String sql = "DELETE FROM tblproduct where maSP = ?";
		        PreparedStatement statement = connection.prepareStatement(sql);
		        statement.setString(1, sp.getMaSP());
		         
		        rowDeleted = statement.executeUpdate() > 0;
		        statement.close();
		    } catch (ClassNotFoundException | SQLException e) {
		        e.printStackTrace(); 
		    }
	        return rowDeleted;     
	 }
	
}
