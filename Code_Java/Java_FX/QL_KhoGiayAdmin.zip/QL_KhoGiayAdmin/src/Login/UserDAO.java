package Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
	public static List<User> listAllUser() {
		List<User> listUser = new ArrayList<>();

		String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		String jdbcUser = "";
		String jdbcPass = "";

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
			String sql = "Select * from tbluser";
			Statement ps = con.createStatement();

			ResultSet rs = ps.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setEmail(rs.getString("email"));
				user.setFullname(rs.getString("fullname"));
				user.setPassword(rs.getString("password"));

				// Them vao danh sach
				listUser.add(user);
			}
			rs.close();
			ps.close();
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ko thấy driver");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return listUser;
	}

	public static User checkUser(String email) {
		User user = null;

		String jdbcURL = "jdbc:ucanaccess://lib/QuanLy.accdb";
		String jdbcUser = "";
		String jdbcPass = "";

		try {
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
			Connection con = DriverManager.getConnection(jdbcURL, jdbcUser, jdbcPass);
			String sql = "Select * from tbluser Where email = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, email);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				user = new User();
				user.setEmail(email);
				user.setFullname(rs.getString("fullname"));
				user.setPassword(rs.getString("password"));
				user.setRole(rs.getInt("role"));
			}
			con.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Ko thấy driver");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

		return user;
	}
}
