package Login;

public class Product {

	private String imgPath;
	private String maSP;
	private String tenSP;
	private String slgSP;
	private String giaSP;
	private String thuonghieuSP;

	public Product() {

	}

	public Product(String imgPath, String maSP, String tenSP, String slgSP, String giaSP, String thuonghieuSP) {
		this.imgPath=imgPath;
		this.maSP = maSP;
		this.tenSP = tenSP;
		this.giaSP = giaSP;
		this.slgSP = slgSP;
		this.thuonghieuSP = thuonghieuSP;
	}

	public String getMaSP() {
		return maSP;
	}

	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}

	public String getTenSP() {
		return tenSP;
	}

	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}

	public String getSlgSP() {
		return slgSP;
	}

	public void setSlgSP(String slgSP) {
		this.slgSP = slgSP;
	}

	public String getGiaSP() {
		return giaSP;
	}

	public void setGiaSP(String giaSP) {
		this.giaSP = giaSP;
	}

	public String getThuonghieuSP() {
		return thuonghieuSP;
	}

	public void setThuonghieuSP(String thuonghieuSP) {
		this.thuonghieuSP = thuonghieuSP;
	}

	public String getImgPath() {
		return imgPath;
	}

	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}

}
