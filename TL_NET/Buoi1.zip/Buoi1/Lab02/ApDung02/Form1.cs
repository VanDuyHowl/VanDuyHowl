﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string pass;
        private void Form1_Load(object sender, EventArgs e)
        {
            txtPass.Text = "";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            pass += "1";
            txtPass.Text = pass;
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            pass += "2";
            txtPass.Text = pass;
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            pass += "3";
            txtPass.Text = pass;
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            pass += "4";
            txtPass.Text = pass;
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            pass += "5";
            txtPass.Text = pass;
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            pass += "6";
            txtPass.Text = pass;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            pass += "7";
            txtPass.Text = pass;

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            pass += "8";
            txtPass.Text = pass;
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            pass += "9";
            txtPass.Text = pass;
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if(txtPass.Text == "1496" || txtPass.Text == "2673")
            {
                ListViewItem liv = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                liv.SubItems.Add("Phát tiển công nghệ");
                liv.SubItems.Add("Chấp nhận");
                
                //them vao listV
                listKetqua.Items.Add(liv);
            }else if(txtPass.Text == "7462")
            {
                ListViewItem liv = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                liv.SubItems.Add("Nghiên cứu viên");
                liv.SubItems.Add("Chấp nhận");
                listKetqua.Items.Add(liv);
            }
            else if (txtPass.Text == "8884" || txtPass.Text == "3842" || txtPass.Text == "3383")
            {
                ListViewItem liv = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                liv.SubItems.Add("Thiết kế mô hình");
                liv.SubItems.Add("Chấp nhận");
                listKetqua.Items.Add(liv);
            }
            else
            {
                ListViewItem liv = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                liv.SubItems.Add("Không có");
                liv.SubItems.Add("Từ chối");
                listKetqua.Items.Add(liv);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            pass = "";
            txtPass.Clear();
        }
    }
}
