﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Apdung01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn muốn thoát?","Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            int a = int.Parse(txtNhapA.Text);
            int b = int.Parse(txtNhapB.Text);

            if(radUSCLN.Checked == true)
            {
                txtKetQua.Text = TimUSCLN(a, b).ToString();
        
            }else if(radBSCNN.Checked == true) {
                txtKetQua.Text = TimBSCNN(a, b).ToString();
            }


        }

        public int TimUSCLN(int a, int b)
        {
            int r = a % b;
            while(r!=0)
            {
                a = b;
                b=r;
                r = a%b;
            }
            return b; 
        }
        public int TimBSCNN(int a, int b)
        {

            return a;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radUSCLN.Checked = true;
        }
    }
}
