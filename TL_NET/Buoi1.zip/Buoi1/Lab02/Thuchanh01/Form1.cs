﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Thuchanh01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Thoát chương trình?","Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtNhapA.Clear();
            txtNhapB.Clear();
            txtKetQua.Clear();
        }

        private void btnCong_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a + b;
                txtKetQua.Text= c.ToString();
            }catch(Exception ex) {
                MessageBox.Show("Lỗi nhập a hoặc b!" + ex.ToString());
            }

            
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a - b;
                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập a hoặc b!" + ex.ToString());
            }
        }

        private void btnNhan_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);

                int c = a * b;
                txtKetQua.Text = c.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập a hoặc b!" + ex.ToString());
            }
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            try
            {
                int a = int.Parse(txtNhapA.Text);
                int b = int.Parse(txtNhapB.Text);
                if(b==0)
                {
                    MessageBox.Show("b phải khác 0!", "Cảnh báo!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    float c = (float)a/b;
                    txtKetQua.Text = c.ToString();
                }

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập a hoặc b!" + ex.ToString());
            }
        }
    }
}
