# Bài tập thực hành Học phần Lập trình .NET - Học viện Nông nghiệp Việt Nam
## Người soạn: Hoàng Văn Tuân

- Buổi 1: Ôn tập và thực hành Console + winform cơ bản
- Buổi 2: Winform nâng cao + kết nối và truy vấn CSDL
- Buổi 3: Winform nâng cao + thêm, sửa, xóa dữ liệu với CSDL
- Buổi 4: Winform nâng cao + sử dụng thủ tục nội tại (Store Procedure)
- Buổi 5: Winform nâng cao + tương tác với SqlDataAdapter
- Buổi 6: Winform nâng cao + in ấn dữ liệu