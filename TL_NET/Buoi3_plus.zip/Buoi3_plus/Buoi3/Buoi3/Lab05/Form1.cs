﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Lab05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn muốn thoát?","Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);

            if (result == DialogResult.Yes) Close();
        }

        string strcon = @"Data Source=M16;Initial Catalog=QLy_SV;Integrated Security=True";
        SqlConnection sqlcon = null;
        private void MoKetNoi()
        {
            if (sqlcon == null) sqlcon = new SqlConnection(strcon);
            if(sqlcon.State ==ConnectionState.Closed) sqlcon.Open();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

            btnSua.Enabled=false;
            btnXoa.Enabled=false;
            groupBox2.Enabled=false;
            hienThiDS_SV();

            cbGT.Items.Add("Nam");
            cbGT.Items.Add("Nữ");

        }

        private void hienThiDS_SV()
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand(strcon);
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV";

            //Gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi ket noi
            SqlDataReader data= sqlcmd.ExecuteReader();
            liV_DS_SinhVien.Items.Clear();
            while(data.Read())
            {
                //Thuc thi truy van
                string maSV = data.GetString(0).Trim();
                string tenSV = data.GetString(1).Trim();
                string gioiTinh=data.GetString(2).Trim();
                string ngaySinh= data.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = data.GetString(4).Trim();
                string maLop = data.GetString(5).Trim();

                //Tao 1 dong noi

                ListViewItem liv = new ListViewItem(maSV);
                liv.SubItems.Add(tenSV);
                liv.SubItems.Add(gioiTinh);
                liv.SubItems.Add(ngaySinh);
                liv.SubItems.Add(queQuan);
                liv.SubItems.Add(maLop);

                //gan ket noi
                liV_DS_SinhVien.Items.Add(liv);

            }
            data.Close();

        }

        //Tim kiem theo ma
        private void TimKiemTheoMa(string maSV)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand(strcon);
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV where MaSV='"+ maSV + "'";

            //Gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi ket noi
            SqlDataReader data = sqlcmd.ExecuteReader();
            liV_DS_SinhVien.Items.Clear();
            while (data.Read())
            {
                //Thuc thi truy van
                string tk_maSV = data.GetString(0).Trim();
                string tenSV = data.GetString(1).Trim();
                string gioiTinh = data.GetString(2).Trim();
                string ngaySinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = data.GetString(4).Trim();
                string maLop = data.GetString(5).Trim();

                //Tao 1 dong noi

                ListViewItem liv = new ListViewItem(tk_maSV);
                liv.SubItems.Add(tenSV);
                liv.SubItems.Add(gioiTinh);
                liv.SubItems.Add(ngaySinh);
                liv.SubItems.Add(queQuan);
                liv.SubItems.Add(maLop);

                //gan ket noi
                liV_DS_SinhVien.Items.Add(liv);

            }
            data.Close();
        }
        //Tim kiem theo ma
        private void TimKiemTheoTen(string tenSV)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand(strcon);
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV where tenSV like N'%" + tenSV + "%'";

            //Gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi ket noi
            SqlDataReader data = sqlcmd.ExecuteReader();
            liV_DS_SinhVien.Items.Clear();
            while (data.Read())
            {
                //Thuc thi truy van
                string maSV = data.GetString(0).Trim();
                string tk_tenSV = data.GetString(1).Trim();
                string gioiTinh = data.GetString(2).Trim();
                string ngaySinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = data.GetString(4).Trim();
                string maLop = data.GetString(5).Trim();

                //Tao 1 dong noi

                ListViewItem liv = new ListViewItem(maSV);
                liv.SubItems.Add(tk_tenSV);
                liv.SubItems.Add(gioiTinh);
                liv.SubItems.Add(ngaySinh);
                liv.SubItems.Add(queQuan);
                liv.SubItems.Add(maLop);

                //gan ket noi
                liV_DS_SinhVien.Items.Add(liv);

            }
            data.Close();
        }
        private void ThemSV()
        {
            try
            {
                string maSV=txtMasv.Text;
                string tenSV=txtTensv.Text;
                string gioiTinh = "";
                if (cbGT.SelectedIndex == 0)
                    gioiTinh = "Nam";
                else if (cbGT.SelectedIndex == 1)
                    gioiTinh = "Nữ";

                string ngaySinh = dTPNgaysinh.Value.Year + "/" + dTPNgaysinh.Value.Month + "/" + dTPNgaysinh.Value.Day;
                string queQuan = txtQuequan.Text;
                string maLop = txtMalop.Text;

                MoKetNoi();
                SqlCommand sqlCmd= new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "insert into SV values ('"+txtMasv.Text + "',N'" + txtTensv.Text + "',N'" + cbGT.SelectedItem +"',convert(datetime,'"+dTPNgaysinh.Value+"'),N'"+txtMalop.Text+"','"+txtMalop.Text+"')";

                sqlCmd.Connection = sqlcon;

                int kq = sqlCmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("Thêm thành công!");
                    hienThiDS_SV();
                    XoaDLFrom();
                }
                else
                {
                    MessageBox.Show("Thêm không thành công!");
                    hienThiDS_SV();
                    XoaDLFrom();
                }
            }catch(Exception ex)
            {
                MessageBox.Show("Lỗi ở đây nè!"+ ex.ToString());
                hienThiDS_SV();
                XoaDLFrom();
            }

        }
        private void XoaDLFrom()
        {
            txtMasv.Clear();
            txtTensv.Clear();
            txtQuequan.Clear();
            txtMalop.Clear();
            cbGT.ResetText();
            dTPNgaysinh.Format = DateTimePickerFormat.Short;
  
        }

        private void SuaSV()
        {
            try
            {
                string maSV = txtMasv.Text;
                string tenSV = txtTensv.Text;
                string gioiTinh = "";
                if (cbGT.SelectedIndex == 0)
                    gioiTinh = "Nam";
                else if (cbGT.SelectedIndex == 1)
                    gioiTinh = "Nữ";

                string ngaySinh = dTPNgaysinh.Value.Year + "/" + dTPNgaysinh.Value.Month + "/" + dTPNgaysinh.Value.Day;
                string queQuan = txtQuequan.Text;
                string maLop = txtMalop.Text;

                MoKetNoi();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.Text;
                sqlCmd.CommandText = "update SV set TenSV=N'"+txtTensv.Text+"',GioiTinh=N'"+cbGT.SelectedItem+ "',NgaySinh=convert(datetime,'" + dTPNgaysinh.Text+"'),QueQuan=N'"+txtQuequan.Text+"',MaLop=N'"+txtMalop.Text+"' where MaSV='"+txtMasv.Text+"'";

                sqlCmd.Connection = sqlcon;

                int kq = sqlCmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("Sửa thành công!");
                    hienThiDS_SV();
                    XoaDLFrom();
                }
                else
                {
                    MessageBox.Show("Sửa khong thành công!");
                    hienThiDS_SV();
                    XoaDLFrom();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ở đây nè!" + ex.ToString());
                hienThiDS_SV();
                XoaDLFrom();
                groupBox2.Enabled=false;    
            }
        }
        private void XoaSV()
        {
            MoKetNoi();
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "delete from SV where MaSV='"+ ma_Xoa + "'";

            sqlCmd.Connection = sqlcon;

            int kq = sqlCmd.ExecuteNonQuery();
            if (kq > 0)
            {
                MessageBox.Show("Xóa thành công!");
                hienThiDS_SV();
                XoaDLFrom();
            }
            else
            {
                MessageBox.Show("Xóa không thành công!");
                hienThiDS_SV();
                XoaDLFrom();
                btnXoa.Enabled = false;
                btnSua.Enabled = false;
            }

        }
        private void btnTK_Click(object sender, EventArgs e)
        {

            //Lay du lieu tren from
            string maSV = txtTKMasv.Text.Trim();
            string tenSV = txtTKTensv.Text.Trim();

            if (maSV !="" && tenSV == "")
                TimKiemTheoMa(maSV);
            else if (maSV == "" && tenSV != "")
                TimKiemTheoTen(tenSV);
            else if(maSV != "" && tenSV != "")
                TimKiemTheoMa(maSV);
            else
            {
                MessageBox.Show("Bạn chưa nhập dữ liệu!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTKMasv.Focus();
            }

        }

        int chucNang = 0;

        private void btnThem_Click(object sender, EventArgs e)
        {
            chucNang = 1;
            groupBox2.Enabled = true;

        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            chucNang = 2;
            groupBox2.Enabled = true;

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (chucNang == 1)
                ThemSV();
            else if (chucNang == 2)
                SuaSV();

            btnSua.Enabled = false;
            groupBox2.Enabled=false;
        }

        string ma_Xoa;
        private void liV_DS_SinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSua.Enabled = true;
            btnXoa.Enabled = true;

            if (liV_DS_SinhVien.SelectedItems.Count == 0) return;

            ListViewItem liv = liV_DS_SinhVien.SelectedItems[0];
            txtMasv.Text = liv.SubItems[0].Text;
            txtTensv.Text = liv.SubItems[1].Text;

            if (liv.SubItems[2].Text == "Nam")
                cbGT.SelectedIndex=0;
            else cbGT.SelectedIndex=1;

            string[] ns = liv.SubItems[3].Text.Split('/');
            dTPNgaysinh.Value = new DateTime(int.Parse(ns[2]), int.Parse(ns[0]), int.Parse(ns[1]));
            txtQuequan.Text = liv.SubItems[4].Text;
            txtMalop.Text = liv.SubItems[5].Text;

           ma_Xoa = liv.SubItems[0].Text;

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn xóa không?", "Hộp thoại", MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                 XoaSV();

            }
            else
            {
                btnXoa.Enabled = false;
                btnSua.Enabled = false;
            }
        }
    }
}
