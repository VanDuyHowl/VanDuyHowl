﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SoLuongSV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string strCon = @"Data Source=M18;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlCon = null;

        private void moKetNoi()
        {
            if(sqlCon== null) sqlCon= new SqlConnection(strCon);
            if(sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
        }

        private void dongKetNoi()
        {
            if(sqlCon != null && sqlCon.State == ConnectionState.Open)
            {
                sqlCon.Close();
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            moKetNoi();

            SqlCommand sqlCmd = new SqlCommand(strCon);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select count(*) from SinhVien";
            sqlCmd.Connection = sqlCon;

            int kq = (int)sqlCmd.ExecuteScalar();
            MessageBox.Show("So luong sinh vien la: " + kq);

        }
    }
}
