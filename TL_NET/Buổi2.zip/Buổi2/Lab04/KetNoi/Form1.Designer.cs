﻿namespace KetNoi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_kn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_kn
            // 
            this.btn_kn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btn_kn.Location = new System.Drawing.Point(133, 96);
            this.btn_kn.Name = "btn_kn";
            this.btn_kn.Size = new System.Drawing.Size(108, 46);
            this.btn_kn.TabIndex = 0;
            this.btn_kn.Text = "Kết nối";
            this.btn_kn.UseVisualStyleBackColor = false;
            this.btn_kn.Click += new System.EventHandler(this.btn_kn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 243);
            this.Controls.Add(this.btn_kn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_kn;
    }
}

